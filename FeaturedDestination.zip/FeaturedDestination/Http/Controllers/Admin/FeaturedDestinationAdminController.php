<?php

namespace Modules\FeaturedDestination\Http\Controllers\Admin;

use App\Contracts\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Schema;
use Modules\FeaturedDestination\Models\FeaturedDestinationSetting;
use Modules\FeaturedDestination\Models\FeaturedDestinationAirport;

class FeaturedDestinationAdminController extends Controller
{
    public function settings()
    {
        $data = [
            'fd_enabled'        => FeaturedDestinationSetting::getValue('fd_enabled', '1'),
            'fd_featured_count' => FeaturedDestinationSetting::getValue('fd_featured_count', '6'),
            'fd_rotation_mode'  => FeaturedDestinationSetting::getValue('fd_rotation_mode', 'manual'),
            'fd_period_days'    => FeaturedDestinationSetting::getValue('fd_period_days', '14'),
            'fd_show_images'    => FeaturedDestinationSetting::getValue('fd_show_images', '1'),
        ];

        return view('featureddestination::admin.settings', $data);
    }

    public function saveSettings(Request $request)
    {
        $validated = $request->validate([
            'fd_enabled'        => 'nullable|in:0,1',
            'fd_show_images'    => 'nullable|in:0,1',
            'fd_featured_count' => 'required|integer|min:1|max:24',
            'fd_rotation_mode'  => 'required|in:manual,auto_random',
            'fd_period_days'    => 'required|integer|min:1|max:365',
        ]);

        FeaturedDestinationSetting::setValue('fd_enabled', $validated['fd_enabled'] ?? '0');
        FeaturedDestinationSetting::setValue('fd_show_images', $validated['fd_show_images'] ?? '0');
        FeaturedDestinationSetting::setValue('fd_featured_count', (string) $validated['fd_featured_count']);
        FeaturedDestinationSetting::setValue('fd_rotation_mode', (string) $validated['fd_rotation_mode']);
        FeaturedDestinationSetting::setValue('fd_period_days', (string) $validated['fd_period_days']);

        return redirect()->route('featureddestination.admin.settings')
            ->with('success', 'Featured Destination settings saved.');
    }

    public function airportsIndex(Request $request)
    {
        $q = trim((string) $request->get('q', ''));

        // Detect available columns in airports table (phpVMS installs differ)
        $cols = [
            'id'      => Schema::hasColumn('airports', 'id'),
            'name'    => Schema::hasColumn('airports', 'name'),
            'iata'    => Schema::hasColumn('airports', 'iata'),
            'icao'    => Schema::hasColumn('airports', 'icao'),
            'city'    => Schema::hasColumn('airports', 'city'),
            'country' => Schema::hasColumn('airports', 'country'),
            'location'=> Schema::hasColumn('airports', 'location'),
            'region'  => Schema::hasColumn('airports', 'region'),
            'state'   => Schema::hasColumn('airports', 'state'),
        ];

        $select = [
            'a.id as airport_id',
        ];

        if ($cols['name']) $select[] = 'a.name as airport_name';
        if ($cols['iata']) $select[] = 'a.iata';
        if ($cols['icao']) $select[] = 'a.icao';

        if ($cols['city']) $select[] = 'a.city';
        if ($cols['country']) $select[] = 'a.country';
        if ($cols['location']) $select[] = 'a.location';
        if ($cols['region']) $select[] = 'a.region';
        if ($cols['state']) $select[] = 'a.state';

        // Meta
        $select[] = 'f.is_featured';
        $select[] = 'f.priority';
        $select[] = 'f.image_path';
        $select[] = 'f.image_url';
        $select[] = 'f.featured_from';
        $select[] = 'f.featured_to';

        $query = DB::table('airports as a')
            ->leftJoin('fd_airports as f', 'f.airport_id', '=', 'a.id')
            ->select($select);

        if ($q !== '') {
            $query->where(function ($w) use ($q, $cols) {
                $w->where('a.id', 'like', "%{$q}%");

                if ($cols['name'])    $w->orWhere('a.name', 'like', "%{$q}%");
                if ($cols['iata'])    $w->orWhere('a.iata', 'like', "%{$q}%");
                if ($cols['icao'])    $w->orWhere('a.icao', 'like', "%{$q}%");
                if ($cols['city'])    $w->orWhere('a.city', 'like', "%{$q}%");
                if ($cols['country']) $w->orWhere('a.country', 'like', "%{$q}%");
                if ($cols['location'])$w->orWhere('a.location', 'like', "%{$q}%");
                if ($cols['region'])  $w->orWhere('a.region', 'like', "%{$q}%");
                if ($cols['state'])   $w->orWhere('a.state', 'like', "%{$q}%");
            });
        }

        $airports = $query
            ->orderBy('a.id', 'asc')
            ->paginate(50)
            ->appends(['q' => $q]);

        return view('featureddestination::admin.airports.index', [
            'airports' => $airports,
            'q' => $q,
            'airport_cols' => $cols,
        ]);
    }

    public function airportsEdit(string $airport_id)
    {
        $airport = DB::table('airports')->where('id', $airport_id)->first();
        abort_if(!$airport, 404);

        $meta = FeaturedDestinationAirport::query()
            ->where('airport_id', $airport_id)
            ->first();

        if (!$meta) {
            $meta = new FeaturedDestinationAirport([
                'airport_id' => $airport_id,
                'priority' => 100,
                'is_featured' => false,
            ]);
        }

        return view('featureddestination::admin.airports.edit', [
            'airport' => $airport,
            'meta' => $meta,
        ]);
    }

    /**
     * Normalize various date inputs into DB-safe 'Y-m-d H:i:s' or null.
     * Accepts:
     * - dd-mm-YYYY HH:ii
     * - dd-mm-YYYY HH:ii:ss
     * - YYYY-mm-dd HH:ii
     * - YYYY-mm-dd HH:ii:ss
     * - YYYY-mm-ddTHH:ii
     * - empty => null
     */
    private function normalizeDateTime(?string $value): ?string
    {
        $v = trim((string) $value);
        if ($v === '') return null;

        // Convert ISO "T" to space
        $v = str_replace('T', ' ', $v);

        // Try known formats first (most strict)
        $formats = [
            'd-m-Y H:i:s',
            'd-m-Y H:i',
            'Y-m-d H:i:s',
            'Y-m-d H:i',
        ];

        foreach ($formats as $fmt) {
            try {
                $dt = \Carbon\Carbon::createFromFormat($fmt, $v);
                return $dt->format('Y-m-d H:i:s');
            } catch (\Throwable $e) {
                // keep trying
            }
        }

        // Fallback: Carbon parse (last resort)
        try {
            return \Carbon\Carbon::parse($v)->format('Y-m-d H:i:s');
        } catch (\Throwable $e) {
            return null; // invalid => store as null
        }
    }

    public function airportsUpdate(Request $request, string $airport_id)
    {
        $airport = DB::table('airports')->where('id', $airport_id)->first();
        abort_if(!$airport, 404);

        // ✅ We validate the text format ourselves (because NL dd-mm-yyyy is not Laravel's default "date")
        $validated = $request->validate([
            'title'         => 'nullable|string|max:120',
            'subtitle'      => 'nullable|string|max:160',
            'description'   => 'nullable|string|max:5000',
            'priority'      => 'required|integer|min:0|max:9999',
            'is_featured'   => 'nullable|in:0,1',

            // accept as string, normalize ourselves
            'featured_from' => 'nullable|string|max:40',
            'featured_to'   => 'nullable|string|max:40',

            'image_url'     => 'nullable|string|max:500|url',

            'image'         => 'nullable|image|max:4096',
            'remove_image'  => 'nullable|in:0,1',
        ]);

        $meta = FeaturedDestinationAirport::query()->firstOrNew(['airport_id' => $airport_id]);

        $meta->title = $validated['title'] ?? null;
        $meta->subtitle = $validated['subtitle'] ?? null;
        $meta->description = $validated['description'] ?? null;
        $meta->priority = (int) $validated['priority'];
        $meta->is_featured = (($validated['is_featured'] ?? '0') === '1');

        // ✅ Normalize datetimes to DB-safe format
        $fromNorm = $this->normalizeDateTime($validated['featured_from'] ?? null);
        $toNorm   = $this->normalizeDateTime($validated['featured_to'] ?? null);

        // ✅ Enforce to >= from if both exist
        if ($fromNorm && $toNorm) {
            try {
                $fromC = \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $fromNorm);
                $toC   = \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $toNorm);
                if ($toC->lt($fromC)) {
                    return back()
                        ->withErrors(['featured_to' => 'Featured To must be after or equal to Featured From.'])
                        ->withInput();
                }
            } catch (\Throwable $e) {
                // ignore (should not happen)
            }
        }

        $meta->featured_from = $fromNorm;
        $meta->featured_to   = $toNorm;

        // ✅ Remove both image sources
        if (($validated['remove_image'] ?? '0') === '1') {
            if ($meta->image_path) {
                try { Storage::disk('public')->delete($meta->image_path); } catch (\Throwable $e) {}
            }
            $meta->image_path = null;
            $meta->image_url  = null;
        }

        // ✅ Save URL (жээ). If URL is set, clear uploaded file to avoid confusion.
        $imageUrl = trim((string) ($validated['image_url'] ?? ''));
        if ($imageUrl !== '') {
            $meta->image_url = $imageUrl;

            // If there was an uploaded file, remove it (keeps storage clean)
            if ($meta->image_path) {
                try { Storage::disk('public')->delete($meta->image_path); } catch (\Throwable $e) {}
            }
            $meta->image_path = null;
        }

        // ✅ Upload new image (upload wins and clears URL)
        if ($request->hasFile('image')) {
            $path = $request->file('image')->store('featureddestination/airports', 'public');

            if ($meta->image_path) {
                try { Storage::disk('public')->delete($meta->image_path); } catch (\Throwable $e) {}
            }

            $meta->image_url = null;
            $meta->image_path = $path;
        }

        $meta->save();

        return redirect()->route('featureddestination.admin.airports.edit', [$airport_id])
            ->with('success', 'Airport details saved.');
    }
}
