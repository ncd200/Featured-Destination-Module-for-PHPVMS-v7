<?php

namespace Modules\FeaturedDestination\Providers;

use App\Contracts\Modules\ServiceProvider;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\Schema\Blueprint;

class FeaturedDestinationServiceProvider extends ServiceProvider
{
    /** @var mixed */
    private $moduleSvc;

    protected $defer = false;

    public function boot(): void
    {
        // phpVMS module service (menus/links)
        $this->moduleSvc = app('App\Services\ModuleService');

        // Routes + views
        $this->loadModuleRoutes();
        $this->registerViews();

        // Tables created here (no migrations)
        $this->createTables();

        // Patch/upgrade schema changes (no migrations)
        $this->ensureSchema();

        // Admin menu (ONLY 1 item in sidebar)
        $this->registerLinks();
    }

    public function register()
    {
        // No container bindings required right now
    }

    protected function loadModuleRoutes(): void
    {
        Route::middleware('web')->group(function () {
            $admin = __DIR__ . '/../Routes/admin.php';
            if (is_file($admin)) require $admin;

            $web = __DIR__ . '/../Routes/web.php';
            if (is_file($web)) require $web;
        });
    }

    protected function registerViews(): void
    {
        $this->loadViewsFrom(__DIR__ . '/../Resources/views', 'featureddestination');
    }

    /**
     * Create all module tables here (no migrations).
     */
    protected function createTables(): void
    {
        // SETTINGS TABLE
        if (!Schema::hasTable('fd_settings')) {
            Schema::create('fd_settings', function (Blueprint $t) {
                $t->bigIncrements('id');
                $t->string('key')->unique();
                $t->longText('value')->nullable();
                $t->timestamps();
            });
        }

        // AIRPORT META TABLE
        if (!Schema::hasTable('fd_airports')) {
            Schema::create('fd_airports', function (Blueprint $t) {
                $t->bigIncrements('id');

                // airports.id (string in your installs like "EGCC", or int in others)
                $t->string('airport_id', 20)->unique();

                $t->string('title', 120)->nullable();
                $t->string('subtitle', 160)->nullable();
                $t->longText('description')->nullable();

                $t->boolean('is_featured')->default(false);
                $t->integer('priority')->default(100);

                $t->dateTime('featured_from')->nullable();
                $t->dateTime('featured_to')->nullable();

                // upload path on public disk
                $t->string('image_path', 255)->nullable();

                // ✅ NEW: direct image link
                $t->string('image_url', 500)->nullable();

                $t->timestamps();

                $t->index(['is_featured', 'priority']);
                $t->index(['featured_from', 'featured_to']);
            });
        }
    }

    /**
     * Upgrade-safe schema patches (no migrations).
     */
    private function ensureSchema(): void
    {
        // ✅ fd_airports.image_url
        if (Schema::hasTable('fd_airports') && !Schema::hasColumn('fd_airports', 'image_url')) {
            Schema::table('fd_airports', function (Blueprint $t) {
                $t->string('image_url', 500)->nullable()->after('image_path');
            });
        }
    }

    /**
     * Adds ONLY 1 admin menu entry with PE7 icon
     */
    public function registerLinks(): void
    {
        $adminUrl = '/admin/featureddestination/settings';

        try {
            if (Route::has('featureddestination.admin.settings')) {
                $adminUrl = route('featureddestination.admin.settings');
            }
        } catch (\Throwable $e) { /* ignore */ }

        try {
            $this->moduleSvc->addAdminLink('Featured Destinations', $adminUrl, 'pe-7s-map-marker');
        } catch (\Throwable $e) {
            $this->moduleSvc->addAdminLink('Featured Destinations', $adminUrl);
        }
    }
}
