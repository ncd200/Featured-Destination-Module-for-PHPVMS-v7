<?php

namespace Modules\FeaturedDestination\Widgets;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Modules\FeaturedDestination\Models\FeaturedDestinationSetting;

class FeaturedDestinationsWidget
{
    public static function render(array $opts = []): string
    {
        $enabled = FeaturedDestinationSetting::getValue('fd_enabled', '1') === '1';
        if (!$enabled) {
            return view('featureddestination::widgets.featured_destinations_section', [
                'airports'  => collect(),
                'theme'     => $opts['theme'] ?? 'dark',
                'title'     => $opts['title'] ?? 'Featured Destinations',
                'subtitle'  => $opts['subtitle'] ?? 'Hand-picked routes from Arrow VA — explore new airports every week.',
            ])->render();
        }

        $count = (int) FeaturedDestinationSetting::getValue('fd_featured_count', '6');
        if ($count < 1) $count = 6;

        $rotation = FeaturedDestinationSetting::getValue('fd_rotation_mode', 'manual');

        // ✅ Use DB time (prevents timezone + string compare issues)
        $q = DB::table('fd_airports as f')
            ->where('f.is_featured', 1)
            ->where(function ($w) {
                $w->whereNull('f.featured_from')
                  ->orWhereRaw('f.featured_from <= NOW()');
            })
            ->where(function ($w) {
                $w->whereNull('f.featured_to')
                  ->orWhereRaw('f.featured_to >= NOW()');
            });

        // Optional join to airports table for display values
        if (Schema::hasTable('airports')) {
            $q->leftJoin('airports as a', 'a.id', '=', 'f.airport_id');

            $select = [
                'f.airport_id',
                'f.priority',
                'f.image_path',
                'f.image_url',
                'f.title',
                'f.subtitle',
                'f.description',

                // ✅ Pass window to view (modal/badges if you want)
                'f.featured_from',
                'f.featured_to',
            ];

            if (Schema::hasColumn('airports', 'name'))  $select[] = 'a.name as airport_name';
            if (Schema::hasColumn('airports', 'iata'))  $select[] = 'a.iata as iata';
            if (Schema::hasColumn('airports', 'icao'))  $select[] = 'a.icao as icao';
            if (Schema::hasColumn('airports', 'city'))  $select[] = 'a.city as city';
            if (Schema::hasColumn('airports', 'country')) $select[] = 'a.country as country';

            $q->select($select);
        } else {
            $q->select([
                'f.airport_id',
                'f.priority',
                'f.image_path',
                'f.image_url',
                'f.title',
                'f.subtitle',
                'f.description',
                'f.featured_from',
                'f.featured_to',
            ]);
        }

        // Rotation
        if ($rotation === 'auto_random') {
            $q->inRandomOrder();
        } else {
            $q->orderBy('f.priority', 'asc')
              ->orderBy('f.airport_id', 'asc');
        }

        // Limit
        $airports = $q->limit($count)->get();

        return view('featureddestination::widgets.featured_destinations_section', [
            'airports'  => $airports,
            'theme'     => $opts['theme'] ?? 'dark',
            'title'     => $opts['title'] ?? 'Featured Destinations',
            'subtitle'  => $opts['subtitle'] ?? 'Hand-picked routes from Arrow VA — explore new airports every week.',
        ])->render();
    }
}
