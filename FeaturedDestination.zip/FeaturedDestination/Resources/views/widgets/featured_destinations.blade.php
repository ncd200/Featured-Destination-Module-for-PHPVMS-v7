<div class="card custom-card">
  <div class="card-header d-flex align-items-center justify-content-between">
    <div class="fw-semibold">{{ $title }}</div>
    <span class="text-muted small">{{ count($items) }} shown</span>
  </div>

  <div class="card-body">
    @if(count($items) === 0)
      <div class="text-muted">No featured destinations configured.</div>
    @else
      <div class="row g-3">
        @foreach($items as $it)
          <div class="col-xl-4 col-lg-6">
            <div class="border rounded-3 h-100 p-3">
              @if($showImages && $it->image_path)
                <div class="mb-2">
                  <img
                    src="{{ asset('storage/'.$it->image_path) }}"
                    alt="{{ $it->airport_name }}"
                    style="width:100%; height:140px; object-fit:cover; border-radius:12px; border:1px solid rgba(0,0,0,.08);"
                  >
                </div>
              @endif

              <div class="d-flex align-items-start justify-content-between gap-2">
                <div>
                  <div class="fw-semibold">
                    {{ $it->title ?: ($it->airport_name ?: $it->airport_id) }}
                  </div>
                  <div class="text-muted small">
                    {{ $it->airport_id }}
                    @if($it->iata || $it->icao)
                      � {{ $it->iata ?: '�' }}/{{ $it->icao ?: '�' }}
                    @endif
                  </div>
                </div>
                <span class="badge bg-light text-muted border">{{ $it->country ?: '�' }}</span>
              </div>

              @if($it->subtitle)
                <div class="mt-2 small fw-semibold">{{ $it->subtitle }}</div>
              @endif

              @if($it->description)
                <div class="mt-2 text-muted small" style="line-height:1.35;">
                  {{ \Illuminate\Support\Str::limit(strip_tags($it->description), 140) }}
                </div>
              @endif

              <div class="mt-3 small text-muted">
                {{ $it->city ?: '' }}{{ $it->city ? ',' : '' }} {{ $it->country ?: '' }}
              </div>
            </div>
          </div>
        @endforeach
      </div>
    @endif
  </div>
</div>
