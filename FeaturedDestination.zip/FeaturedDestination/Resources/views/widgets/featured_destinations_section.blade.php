{{-- Featured Destinations - Section (Landing style) --}}
@php
  $airports = $airports ?? collect();

  $title = $title ?? 'Featured Destinations';
  $subtitle = $subtitle ?? 'Hand-picked highlights from our network — explore new airports every week.';

  $fdCols = max(1, min(4, collect($airports)->count()));

  // Theme handling
  $theme = $theme ?? 'dark'; // dark = default op landing
  $isDark = ($theme === 'dark');

  $hText = $isDark ? 'text-fixed-white' : 'text-dark';
  $pText = $isDark ? 'text-fixed-white op-8' : 'text-muted';

  // Fallback image
  $fallbackImg = public_asset('/AeroCore/images/media/landing/web/1.png');

  // Optional tile shadow
  $tileShadow = $tileShadow ?? 'shadow-sm';

  /**
   * FAILSAFE TIME FILTER (blijft!)
   * - featured_from: mag NULL zijn of <= now
   * - featured_to:   mag NULL zijn of >= now
   * - ondersteunt zowel normale datetime als "d-m-Y H:i"
   */
  $now = now();

  $airports = collect($airports)->filter(function ($a) use ($now) {
      $from = $a->featured_from ?? null;
      $to   = $a->featured_to ?? null;

      // parse $from
      try {
          if ($from && !($from instanceof \Carbon\Carbon)) {
              $from = \Carbon\Carbon::parse((string)$from);
          }
      } catch (\Throwable $e) {
          $from = null;
      }

      // parse $to
      try {
          if ($to && !($to instanceof \Carbon\Carbon)) {
              $toStr = (string)$to;

              // format: 06-01-2026 22:12 (dd-mm-yyyy)
              if (preg_match('/^\d{2}-\d{2}-\d{4}\s+\d{2}:\d{2}/', $toStr)) {
                  $to = \Carbon\Carbon::createFromFormat('d-m-Y H:i', $toStr);
              } else {
                  $to = \Carbon\Carbon::parse($toStr);
              }
          }
      } catch (\Throwable $e) {
          $to = null;
      }

      return (!$from || $from <= $now) && (!$to || $to >= $now);
  })->values();
@endphp

<style>
/* ==============================
   HOVER + ARROW GLOW (safe CSS)
   ============================== */

.fd-tiles.fd-rect .fd-tile{
  transition: transform .22s ease, box-shadow .22s ease, filter .22s ease;
  will-change: transform, box-shadow;
}

/* subtle lift */
.fd-tiles.fd-rect .fd-tile:hover{
  transform: translateY(-6px);
  filter: saturate(1.05) contrast(1.03);
}

/* soft glow ring */
.fd-tiles.fd-rect .fd-tile::before{
  content: "";
  position: absolute;
  inset: 0;
  border-radius: 18px;
  pointer-events: none;
  opacity: 0;
  transition: opacity .22s ease;
  box-shadow:
    0 0 0 2px rgba(255,255,255,.06),
    0 18px 44px rgba(0,0,0,.40),
    0 0 34px rgba(0, 173, 181, .22); /* Arrow glow tint (teal-ish) */
}

.fd-tiles.fd-rect .fd-tile:hover::before{
  opacity: 1;
}

/* make overlay slightly brighter on hover */
.fd-tiles.fd-rect .fd-tile:hover .fd-overlay{
  background: linear-gradient(
    to top,
    rgba(0,0,0,.82) 0%,
    rgba(0,0,0,.42) 48%,
    rgba(0,0,0,0) 78%
  ) !important;
}

/* keyboard focus (accessibility) */
.fd-tiles.fd-rect .fd-tile:focus-visible{
  outline: none;
  box-shadow: 0 0 0 3px rgba(0, 173, 181, .35), 0 12px 28px rgba(0,0,0,.28) !important;
  transform: translateY(-4px);
}

/* reduced motion */
@media (prefers-reduced-motion: reduce){
  .fd-tiles.fd-rect .fd-tile,
  .fd-tiles.fd-rect .fd-tile::before{
    transition: none !important;
  }
  .fd-tiles.fd-rect .fd-tile:hover{
    transform: none !important;
  }
}


/* ==============================
   GRID TILES (dynamisch 1–4, altijd gecentreerd)
   ============================== */
.fd-tiles.fd-rect{
  --fd-cols: 4;

  display: grid !important;
  grid-template-columns: repeat(var(--fd-cols), minmax(260px, 1fr)) !important;

  gap: 24px !important;

  width: 100% !important;
  max-width: 1400px !important;
  margin: 0 auto !important;

  /* 🔑 dit centreert de hele “track group” */
  justify-content: center !important;
  align-items: stretch !important;
}

.fd-tiles.fd-rect .trust-img{
  width: 100% !important;
  max-width: 520px !important;
}

/* Responsive */
@media (max-width: 1200px){
  .fd-tiles.fd-rect{
    grid-template-columns: repeat(2, minmax(260px, 1fr)) !important;
    max-width: 980px !important;
  }
}
@media (max-width: 768px){
  .fd-tiles.fd-rect{
    grid-template-columns: 1fr !important;
    max-width: 520px !important;
  }
}

.fd-tiles.fd-rect .trust-img{
  width: 100% !important;
}

.fd-tiles.fd-rect .fd-tile{
  width: 100% !important;
  height: 240px !important;
  position: relative !important;
  overflow: hidden !important;
  border-radius: 18px !important;
  padding: 0 !important;
  box-shadow: 0 12px 28px rgba(0,0,0,.28) !important;
  cursor: pointer !important;
  user-select: none;
}

.fd-tiles.fd-rect .fd-tile img{
  width: 100% !important;
  height: 100% !important;
  object-fit: cover !important;
  object-position: center !important;
  display: block !important;
}

.fd-rect .fd-overlay{
  position: absolute !important;
  inset: 0 !important;
  display: flex !important;
  flex-direction: column !important;
  justify-content: flex-end !important;
  padding: 18px 20px !important;
  background: linear-gradient(to top, rgba(0,0,0,.78) 0%, rgba(0,0,0,.35) 45%, rgba(0,0,0,0) 75%) !important;
}

.fd-rect .fd-code{
  font-size: 22px !important;
  font-weight: 800 !important;
  letter-spacing: .4px !important;
  line-height: 1.05 !important;
}
.fd-rect .fd-name{
  font-size: 14px !important;
  opacity: .95 !important;
  line-height: 1.2 !important;
}


/* ==============================
   MODAL (no bootstrap needed)
   ============================== */
.fd-modal{
  position: fixed;
  inset: 0;
  z-index: 9999;
  display: none;
}
.fd-modal.is-open{ display: block; }

.fd-modal__backdrop{
  position: absolute;
  inset: 0;
  background: rgba(0,0,0,.55);
  backdrop-filter: blur(2px);
}

.fd-modal__dialog{
  position: relative;
  max-width: 980px;
  width: calc(100% - 32px);
  margin: 60px auto;
  border-radius: 18px;
  overflow: hidden;
  background: #0b2b3a;
  box-shadow: 0 24px 60px rgba(0,0,0,.45);
}

.fd-modal__hero{
  position: relative;
  height: 360px;
  background: #111;
}
.fd-modal__hero img{
  width: 100%;
  height: 100%;
  object-fit: cover;
  display: block;
}
.fd-modal__hero::after{
  content:"";
  position:absolute;
  inset:0;
  background: linear-gradient(to top, rgba(11,43,58,.92) 0%, rgba(11,43,58,.35) 52%, rgba(11,43,58,0) 80%);
}

.fd-modal__close{
  position: absolute;
  top: 14px;
  right: 14px;
  width: 40px;
  height: 40px;
  border: 0;
  border-radius: 999px;
  background: rgba(255,255,255,.12);
  color: #fff;
  font-size: 22px;
  line-height: 40px;
  cursor: pointer;
}

.fd-modal__content{
  padding: 18px 18px 16px;
  color: #fff;
}

.fd-modal__kicker{
  font-size: 13px;
  opacity: .85;
  display: flex;
  gap: 8px;
  align-items: center;
  margin-bottom: 6px;
}
.fd-pill{
  display: inline-flex;
  gap: 8px;
  align-items: center;
  padding: 4px 10px;
  border-radius: 999px;
  border: 1px solid rgba(255,255,255,.16);
  background: rgba(255,255,255,.08);
  font-size: 12px;
}

.fd-modal__title{
  font-size: 26px;
  font-weight: 800;
  margin: 0;
  color: #ffffff !important;
}
.fd-modal__subtitle{
  margin-top: 6px;
  font-size: 14px;
  opacity: .9;
}
.fd-modal__desc{
  margin-top: 14px;
  font-size: 14px;
  line-height: 1.55;
  opacity: .92;
  white-space: pre-line;
}
.fd-modal__actions{
  margin-top: 14px;
  display: flex;
  gap: 10px;
  flex-wrap: wrap;
}
.fd-btn{
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border-radius: 10px;
  padding: 10px 14px;
  border: 1px solid rgba(255,255,255,.16);
  text-decoration: none;
  color: #fff;
  font-size: 13px;
  background: rgba(255,255,255,.08);
}
.fd-btn.primary{ background: rgba(255,255,255,.16); }

@media (max-width: 768px){
  .fd-modal__dialog{ margin: 22px auto; }
  .fd-modal__hero{ height: 260px; }
  .fd-modal__title{ font-size: 22px; }
}


/* =========================================================
   HARD KILL: dotted/dashed circle behind tiles (template)
   Put this at the VERY END of the <style> in the blade
   ========================================================= */
#featured-destinations .trust-img,
#featured-destinations .fd-tile,
#featured-destinations .fd-tile img{
  background-image: none !important;
  background: none !important;
  border-image: none !important;
}

/* nuke ANY pseudo element that could draw the ring */
#featured-destinations .trust-img::before,
#featured-destinations .trust-img::after,
#featured-destinations .fd-tile::before,
#featured-destinations .fd-tile::after,
#featured-destinations .fd-tile img::before,
#featured-destinations .fd-tile img::after,
#featured-destinations::before,
#featured-destinations::after{
  content: none !important;
  display: none !important;
  background: none !important;
  background-image: none !important;
  border: 0 !important;
  box-shadow: none !important;
  outline: 0 !important;
}

/* some templates add a decorative svg/bg inside wrappers */
#featured-destinations svg,
#featured-destinations .dots,
#featured-destinations .pattern,
#featured-destinations .circle{
  display: none !important;
}

#featured-destinations.section,
#featured-destinations.section *{
  background-image: none !important;
}

</style>

<section class="section landing-Features" id="featured-destinations">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-xl-8">
        <div class="heading-section text-center mb-0">
          <p class="fs-14 fw-medium text-success mb-1">
            <span class="landing-section-heading landing-section-heading-dark text-success">
              <i class="ti ti-inner-shadow-top-right-filled text-secondary me-1 fs-10"></i>{{ $title }}
            </span>
          </p>

          <h4 class="{{ $hText }} text-center mt-3 fw-medium">
            Fly Something New Today
          </h4>

          <div class="fs-14 {{ $pText }} text-center mb-4">
            {{ $subtitle }}
          </div>
        </div>
      </div>

      <div class="col-xl-11 my-auto">
        <div class="fd-tiles fd-rect" style="--fd-cols: {{ $fdCols }};">
          @forelse($airports as $a)
            @php
              $img = null;
              if (!empty($a->image_url)) $img = $a->image_url;
              elseif (!empty($a->image_path)) $img = asset('storage/'.$a->image_path);
              else $img = $fallbackImg;

              $name = $a->airport_name ?? $a->name ?? $a->airport_id ?? 'Airport';
              $code = $a->icao ?? $a->iata ?? $a->airport_id ?? '';

              $mTitle = $a->title ?? $name;
              $mSub   = $a->subtitle ?? '';
              $mDesc  = $a->description ?? '';

              $airportId = $a->airport_id ?? $a->id ?? null;

              $href = null;
              try {
                if ($airportId && \Illuminate\Support\Facades\Route::has('featureddestination.airport.show')) {
                  $href = route('featureddestination.airport.show', [$airportId]);
                }
              } catch (\Throwable $e) {}
            @endphp

            <div class="trust-img">
              <div class="d-block fd-tile {{ $tileShadow }}"
                   role="button"
                   tabindex="0"
                   data-fd-modal="1"
                   data-img="{{ e($img) }}"
                   data-code="{{ e($code) }}"
                   data-name="{{ e($name) }}"
                   data-title="{{ e($mTitle) }}"
                   data-subtitle="{{ e($mSub) }}"
                   data-desc="{{ e($mDesc) }}"
                   data-href="{{ e($href ?? '') }}">

                <img src="{{ $img }}" alt="{{ $name }}"
                     onerror="this.src='{{ $fallbackImg }}';" />

                <div class="fd-overlay">
                  <div class="text-fixed-white fd-code">{{ $code }}</div>
                  <div class="text-fixed-white fd-name">{{ $name }}</div>
                </div>
              </div>
            </div>

          @empty
            <div class="trust-img">
              <div class="fd-tile shadow-sm d-flex align-items-center justify-content-center"
                   style="height:240px; cursor: default;">
                <div class="text-center px-3">
                  <div class="{{ $isDark ? 'text-fixed-white' : 'text-dark' }} fw-semibold">No featured destinations yet</div>
                  <div class="{{ $isDark ? 'text-fixed-white op-7' : 'text-muted' }}" style="font-size:12px;">
                    Pick some airports in Admin → Airport Directory
                  </div>
                </div>
              </div>
            </div>
          @endforelse
        </div>
      </div>
    </div>
  </div>
</section>

{{-- Modal --}}
<div class="fd-modal" id="fdModal" aria-hidden="true">
  <div class="fd-modal__backdrop" data-fd-close></div>

  <div class="fd-modal__dialog" role="dialog" aria-modal="true" aria-labelledby="fdModalTitle">
    <button class="fd-modal__close" type="button" aria-label="Close" data-fd-close>&times;</button>

    <div class="fd-modal__hero">
      <img id="fdModalImg" src="{{ $fallbackImg }}" alt="">
    </div>

    <div class="fd-modal__content">
      <div class="fd-modal__kicker">
        <span class="fd-pill" id="fdModalCode">—</span>
        <span class="fd-pill" id="fdModalName">—</span>
      </div>

      <h3 class="fd-modal__title" id="fdModalTitle">—</h3>
      <div class="fd-modal__subtitle" id="fdModalSubtitle" style="display:none;"></div>
      <div class="fd-modal__desc" id="fdModalDesc" style="display:none;"></div>

      <div class="fd-modal__actions" id="fdModalActions" style="display:none;">
        <a class="fd-btn primary" id="fdModalLink" href="#" style="display:none;">Open airport page</a>
        <button class="fd-btn" type="button" data-fd-close>Close</button>
      </div>
    </div>
  </div>
</div>

<script>
(function(){
  const modal = document.getElementById('fdModal');
  const img   = document.getElementById('fdModalImg');
  const code  = document.getElementById('fdModalCode');
  const name  = document.getElementById('fdModalName');
  const ttl   = document.getElementById('fdModalTitle');
  const sub   = document.getElementById('fdModalSubtitle');
  const desc  = document.getElementById('fdModalDesc');
  const acts  = document.getElementById('fdModalActions');
  const link  = document.getElementById('fdModalLink');

  const fallback = @json($fallbackImg);

  function openModal(data){
    img.src = data.img || fallback;
    img.onerror = () => { img.src = fallback; };

    code.textContent = data.code || '—';
    name.textContent = data.name || '—';

    ttl.textContent = data.title || data.name || 'Airport';

    if (data.subtitle && data.subtitle.trim().length){
      sub.style.display = 'block';
      sub.textContent = data.subtitle;
    } else {
      sub.style.display = 'none';
      sub.textContent = '';
    }

    if (data.desc && data.desc.trim().length){
      desc.style.display = 'block';
      desc.textContent = data.desc;
    } else {
      desc.style.display = 'none';
      desc.textContent = '';
    }

    acts.style.display = 'flex';
    if (data.href && data.href.trim().length){
      link.style.display = 'inline-flex';
      link.href = data.href;
    } else {
      link.style.display = 'none';
      link.href = '#';
    }

    modal.classList.add('is-open');
    modal.setAttribute('aria-hidden','false');
    document.body.style.overflow = 'hidden';
  }

  function closeModal(){
    modal.classList.remove('is-open');
    modal.setAttribute('aria-hidden','true');
    document.body.style.overflow = '';
  }

  document.addEventListener('click', function(e){
    const close = e.target.closest('[data-fd-close]');
    if (close) { e.preventDefault(); closeModal(); return; }

    const tile = e.target.closest('[data-fd-modal="1"]');
    if (!tile) return;

    openModal({
      img: tile.getAttribute('data-img'),
      code: tile.getAttribute('data-code'),
      name: tile.getAttribute('data-name'),
      title: tile.getAttribute('data-title'),
      subtitle: tile.getAttribute('data-subtitle'),
      desc: tile.getAttribute('data-desc'),
      href: tile.getAttribute('data-href'),
    });
  });

  document.addEventListener('keydown', function(e){
    if (e.key === 'Escape' && modal.classList.contains('is-open')) closeModal();
  });

  document.addEventListener('keydown', function(e){
    const tile = document.activeElement?.closest?.('[data-fd-modal="1"]');
    if (!tile) return;
    if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); tile.click(); }
  });
})();
</script>
