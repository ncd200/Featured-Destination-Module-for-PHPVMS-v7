{{-- Modules/FeaturedDestination/Resources/views/layouts/admin.blade.php --}}
@extends('admin.app')

@section('title', trim($__env->yieldContent('title', 'Featured Destinations')))

{{-- Inject into the default phpVMS admin topbar --}}
@section('actions')
  <li>
    <a href="{{ route('featureddestination.admin.settings') }}"
       class="{{ request()->routeIs('featureddestination.admin.settings') ? 'active' : '' }}">
      Destination Settings
    </a>
  </li>

  <li>
    <a href="{{ route('featureddestination.admin.airports.index') }}"
       class="{{ request()->routeIs('featureddestination.admin.airports.*') ? 'active' : '' }}">
      Airport Directory
    </a>
  </li>
@endsection

@section('content')
  {{-- Support both section names for flexibility --}}
  @hasSection('fd_admin_content')
    @yield('fd_admin_content')
  @else
    @yield('content')
  @endif
@endsection
