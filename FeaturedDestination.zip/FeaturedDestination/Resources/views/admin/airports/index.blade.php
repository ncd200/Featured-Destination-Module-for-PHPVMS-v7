@extends('featureddestination::layouts.admin')

@section('title', 'Featured Destinations - Airport Directory')

@section('fd_admin_content')
@php
  $q = $q ?? '';
@endphp

<style>
  /* Match Settings page look */
  .fd-wrap { width: 100%; max-width: none; }
  .fd-topline { border-top: 3px solid #0b78b6; margin: 8px 0 10px; }

  /* give the module page a light "canvas" background like your settings */
  .fd-canvas {
    background: #f3f5f7;
    padding: 14px;
    border-radius: 6px;
    border: 1px solid rgba(0,0,0,.06);
  }

  .fd-section {
    background: #fff;
    border: 1px solid rgba(0,0,0,.08);
    border-radius: 4px;
    overflow: hidden;
  }
  .fd-section-title {
    padding: 10px 12px;
    border-bottom: 1px solid rgba(0,0,0,.06);
    font-size: 13px;
    font-weight: 700;
    text-align: center;
  }
  .fd-section-body { padding: 12px; }

  .fd-mini { font-size: 12px; color: rgba(0,0,0,.6); }

  .fd-thumb{
    width: 64px;
    height: 42px;
    object-fit: cover;
    border-radius: 10px;
    border: 1px solid rgba(0,0,0,.10);
    background: #f8f9fa;
  }

  /* Make table look closer to the settings/admin panels */
  .fd-table thead th {
    font-weight: 600;
    font-size: 12px;
    color: rgba(0,0,0,.65);
    background: #fff;
    border-bottom: 1px solid rgba(0,0,0,.08) !important;
  }
  .fd-table tbody td {
    font-size: 13px;
    border-top: 1px solid rgba(0,0,0,.06) !important;
    vertical-align: middle;
  }

  .fd-badge {
    display: inline-block;
    padding: 3px 8px;
    border-radius: 999px;
    font-size: 11px;
    border: 1px solid rgba(0,0,0,.10);
    background: rgba(0,0,0,.03);
    white-space: nowrap;
  }
  .fd-badge.scheduled { background: rgba(255,193,7,.14); border-color: rgba(255,193,7,.30); color: #664d03; }
  .fd-badge.active    { background: rgba(25,135,84,.10); border-color: rgba(25,135,84,.25); color: #198754; }
  .fd-badge.expired   { background: rgba(108,117,125,.10); border-color: rgba(108,117,125,.25); color: #6c757d; }
  .fd-badge.inactive  { background: rgba(0,0,0,.03); border-color: rgba(0,0,0,.10); color: rgba(0,0,0,.65); }

  .fd-timer {
    font-size: 12px;
    color: rgba(0,0,0,.65);
    line-height: 1.2;
    white-space: nowrap;
  }
</style>

<div class="fd-wrap">

  {{-- Header --}}
  <div class="d-flex align-items-start justify-content-between flex-wrap gap-2">
    <div>
      <div class="fd-mini">Airport Directory</div>
      <h5 class="mb-0">Manage Airport Images & Details</h5>
      <div class="fd-mini">Add images, subtitles and descriptions to airports for the Featured Destinations widget.</div>
    </div>

    <form method="get" class="d-flex gap-2 align-items-end">
      <div>
        <input class="form-control" style="width:340px;max-width:70vw;"
               type="text" name="q" value="{{ $q }}" placeholder="Search ICAO/IATA/Name/Location...">
      </div>
      <button class="btn btn-outline-secondary" type="submit">Search</button>
      <a class="btn btn-outline-secondary" href="{{ route('featureddestination.admin.airports.index') }}">Reset</a>
    </form>
  </div>

  <div class="fd-topline"></div>

  {{-- Canvas --}}
  <div class="fd-canvas">

    <div class="fd-section">
      <div class="fd-section-title">Airport Directory</div>
      <div class="fd-section-body p-0">

        <div class="table-responsive">
          <table class="table table-hover mb-0 fd-table">
            <thead>
              <tr>
                <th style="width:90px;">Image</th>
                <th>Airport</th>
                <th style="width:110px;">IATA</th>
                <th style="width:110px;">ICAO</th>
                <th>Location</th>
                <th style="width:160px;" class="text-center">Featured</th>
                <th style="width:110px;" class="text-center">Priority</th>
                <th style="width:110px;"></th>
              </tr>
            </thead>

            <tbody>
              @forelse($airports as $a)
                @php
                  $img = null;
                  if (!empty($a->image_url)) $img = $a->image_url;
                  elseif (!empty($a->image_path)) $img = asset('storage/'.$a->image_path);

                  $name = $a->airport_name ?? $a->name ?? $a->airport_id ?? 'Airport';

                  $parts = [];
                  if (!empty($airport_cols['city']) && !empty($a->city)) $parts[] = $a->city;
                  if (!empty($airport_cols['state']) && !empty($a->state)) $parts[] = $a->state;
                  if (!empty($airport_cols['region']) && !empty($a->region)) $parts[] = $a->region;
                  if (!empty($airport_cols['country']) && !empty($a->country)) $parts[] = $a->country;
                  if (empty($parts) && !empty($airport_cols['location']) && !empty($a->location)) $parts[] = $a->location;
                  $loc = count($parts) ? implode(', ', $parts) : '�';

                  $isFeatured = (int)($a->is_featured ?? 0) === 1;

                  // Real schedule fields
                  $startRaw = $a->featured_from ?? null;
                  $endRaw   = $a->featured_to ?? null;

                  $now = now();
                  $startAt = $startRaw ? \Carbon\Carbon::parse($startRaw) : null;
                  $endAt   = $endRaw ? \Carbon\Carbon::parse($endRaw) : null;

                  // Status
                  if ($startAt && $now->lt($startAt)) {
                    $rowStatusLabel = 'SCHEDULED';
                    $rowStatusClass = 'scheduled';
                  } elseif ($startAt && $endAt && $now->between($startAt, $endAt)) {
                    $rowStatusLabel = 'ACTIVE';
                    $rowStatusClass = 'active';
                  } elseif ($endAt && $now->gt($endAt)) {
                    $rowStatusLabel = 'EXPIRED';
                    $rowStatusClass = 'expired';
                  } else {
                    if ($isFeatured) {
                      $rowStatusLabel = 'ACTIVE';
                      $rowStatusClass = 'active';
                    } else {
                      $rowStatusLabel = 'INACTIVE';
                      $rowStatusClass = 'inactive';
                    }
                  }

                  // Countdown (server-side)
                  $timerText = '�';
                  if ($endAt) {
                    if ($now->lt($endAt)) {
                      $mins = $now->diffInMinutes($endAt);
                      $h = intdiv($mins, 60);
                      $m = $mins % 60;
                      $timerText = ($h > 0)
                        ? ($h.'h '.$m.'m left')
                        : ($m.'m left');
                    } else {
                      $timerText = 'Expired';
                    }
                  } elseif ($rowStatusClass === 'scheduled' && $startAt) {
                    // Optional: show time until start if scheduled
                    $mins = $now->diffInMinutes($startAt);
                    $h = intdiv($mins, 60);
                    $m = $mins % 60;
                    $timerText = ($h > 0)
                      ? ('Starts in '.$h.'h '.$m.'m')
                      : ('Starts in '.$m.'m');
                  }
                @endphp

                <tr>
                  <td>
                    @if($img)
                      <img class="fd-thumb" src="{{ $img }}" alt="img" onerror="this.style.display='none'">
                    @else
                      <div class="fd-thumb d-flex align-items-center justify-content-center text-muted" style="font-size:11px;">�</div>
                    @endif
                  </td>

                  <td>
                    <div class="fw-semibold">{{ $name }}</div>
                    <div class="fd-mini">ID: {{ $a->airport_id }}</div>
                  </td>

                  <td>{{ $a->iata ?? '�' }}</td>
                  <td>{{ $a->icao ?? '�' }}</td>
                  <td>{{ $loc }}</td>

                  <td class="text-center">
                    <div class="d-inline-flex flex-column align-items-center gap-1">
                      <span class="fd-badge {{ $rowStatusClass }}">{{ $rowStatusLabel }}</span>
                      <span class="fd-timer">{{ $timerText }}</span>
                    </div>
                  </td>

                  <td class="text-center">
                    <span class="fd-badge">{{ $a->priority ?? 100 }}</span>
                  </td>

                  <td class="text-end">
                    <a class="btn btn-sm btn-primary"
                       href="{{ route('featureddestination.admin.airports.edit', [$a->airport_id]) }}">
                      Edit
                    </a>
                  </td>
                </tr>
              @empty
                <tr>
                  <td colspan="8" class="text-center text-muted py-4">No airports found.</td>
                </tr>
              @endforelse
            </tbody>
          </table>
        </div>

      </div>

      <div style="border-top:3px solid #0b78b6;"></div>

      <div class="p-3">
        {{ $airports->links() }}
      </div>
    </div>

  </div>
</div>
@endsection
