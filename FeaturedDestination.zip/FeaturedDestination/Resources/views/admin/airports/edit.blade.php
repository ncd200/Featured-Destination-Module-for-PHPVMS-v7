@extends('featureddestination::layouts.admin')

@section('title', 'Featured Destinations - Edit Airport')

@section('fd_admin_content')
@php
  $airportId   = $airport->id ?? '';
  $airportName = property_exists($airport, 'name') ? ($airport->name ?? '') : '';
  $iata        = property_exists($airport, 'iata') ? ($airport->iata ?? '') : '';
  $icao        = property_exists($airport, 'icao') ? ($airport->icao ?? '') : '';

  $city        = property_exists($airport, 'city') ? ($airport->city ?? '') : '';
  $state       = property_exists($airport, 'state') ? ($airport->state ?? '') : '';
  $region      = property_exists($airport, 'region') ? ($airport->region ?? '') : '';
  $country     = property_exists($airport, 'country') ? ($airport->country ?? '') : '';
  $location    = property_exists($airport, 'location') ? ($airport->location ?? '') : '';

  $locParts = array_values(array_filter([$city, $state, $region, $country]));
  if (empty($locParts) && !empty($location)) $locParts = [$location];
  $locLine = count($locParts) ? implode(', ', $locParts) : '—';

  $enabledFeatured = old('is_featured', $meta->is_featured ? '1' : '0') === '1';

  $currentImg = null;
  if (!empty($meta->image_url)) $currentImg = $meta->image_url;
  elseif (!empty($meta->image_path)) $currentImg = asset('storage/'.$meta->image_path);
@endphp

<style>
  .fd-wrap { width:100%; max-width:none; }
  .fd-topline { border-top: 3px solid #0b78b6; margin: 6px 0 10px; }

  .fd-section { background:#fff; border:1px solid rgba(0,0,0,.08); border-radius:4px; overflow:hidden; }
  .fd-section-title { padding:10px 12px; border-bottom:1px solid rgba(0,0,0,.06); font-size:13px; font-weight:700; text-align:center; }
  .fd-section-body { padding:14px 14px 8px; }

  .fd-formrow{ display:grid; grid-template-columns:220px 1fr; gap:12px; padding:10px 0; border-bottom:1px solid rgba(0,0,0,.06); align-items:start; }
  .fd-formrow:last-child{ border-bottom:0; }
  .fd-label{ font-size:12px; color: rgba(0,0,0,.75); padding-top:8px; }
  .fd-help{ font-size:11px; color: rgba(0,0,0,.55); margin-top:4px; }

  .fd-actions{ text-align:center; padding:14px 0 8px; }
  .fd-actions .btn{ min-width:160px; }

  .fd-split{ display:grid; grid-template-columns:1fr 360px; gap:14px; }
  @media(max-width:1200px){ .fd-split{ grid-template-columns:1fr; } }

  .fd-mini{ font-size:12px; color: rgba(0,0,0,.6); }
  .fd-pill{ display:inline-block; padding:2px 8px; border-radius:999px; font-size:11px; border:1px solid rgba(0,0,0,.12); background:#f8f9fa; }
  .fd-img{ max-width:100%; border-radius:10px; border:1px solid rgba(0,0,0,.08); }
</style>

<div class="fd-wrap">
  <div class="d-flex align-items-start justify-content-between flex-wrap gap-2">
    <div>
      <div class="fd-mini">Edit Airport</div>
      <h5 class="mb-0">Airport: {{ $airportId }}</h5>
      <div class="fd-mini">{{ $airportName ?: 'Airport' }} — {{ $locLine }}</div>
    </div>

    <div class="d-flex gap-2">
      <a class="btn btn-outline-secondary" href="{{ route('featureddestination.admin.airports.index') }}">Back to Directory</a>
    </div>
  </div>

  <div class="fd-topline"></div>

  <div class="fd-split">
    <div class="fd-section">
      <div class="fd-section-title">Airport Details</div>
      <div class="fd-section-body">
        <form method="post" enctype="multipart/form-data" action="{{ route('featureddestination.admin.airports.update', [$airportId]) }}">
          @csrf

          <div class="fd-formrow">
            <div class="fd-label">Title (optional)</div>
            <div>
              <input class="form-control" name="title" value="{{ old('title', $meta->title) }}">
              <div class="fd-help">Shown as the main headline for this airport (if used in widgets/pages).</div>
            </div>
          </div>

          <div class="fd-formrow">
            <div class="fd-label">Subtitle (optional)</div>
            <div>
              <input class="form-control" name="subtitle" value="{{ old('subtitle', $meta->subtitle) }}">
              <div class="fd-help">Short tagline (e.g. “Gateway to the North”).</div>
            </div>
          </div>

          <div class="fd-formrow">
            <div class="fd-label">Description</div>
            <div>
              <textarea class="form-control" name="description" rows="6">{{ old('description', $meta->description) }}</textarea>
              <div class="fd-help">Displayed on the airport details page and optionally in the widget.</div>
            </div>
          </div>

          <div class="fd-formrow">
            <div class="fd-label">Priority</div>
            <div>
              <input type="number" class="form-control" name="priority" min="0" max="9999" value="{{ old('priority', $meta->priority ?? 100) }}">
              <div class="fd-help">Lower = appears earlier when rotation mode is Manual.</div>
            </div>
          </div>

          <div class="fd-formrow">
            <div class="fd-label">Featured</div>
            <div>
              <div class="form-check form-switch">
                <input class="form-check-input" type="checkbox" id="is_featured" name="is_featured" value="1" {{ $enabledFeatured ? 'checked' : '' }}>
                <label class="form-check-label" for="is_featured" style="font-size:12px;">
                  Mark as Featured
                </label>
              </div>
              <div class="fd-help">Enable to include this airport in the featured pool.</div>
            </div>
          </div>

          <div class="fd-formrow">
            <div class="fd-label">Featured window (optional)</div>
            <div>
              <div class="row g-2">
                <div class="col-md-6">
                  <input type="datetime-local" class="form-control" name="featured_from"
                         value="{{ old('featured_from', $meta->featured_from ? $meta->featured_from->format('Y-m-d\TH:i') : '') }}">
                  <div class="fd-help">From</div>
                </div>
                <div class="col-md-6">
                  <input type="datetime-local" class="form-control" name="featured_to"
                         value="{{ old('featured_to', $meta->featured_to ? $meta->featured_to->format('Y-m-d\TH:i') : '') }}">
                  <div class="fd-help">To</div>
                </div>
              </div>
              <div class="fd-help">Leave empty for always available.</div>
            </div>
          </div>

          {{-- ✅ IMAGE: URL + Upload + Preview --}}
          <div class="fd-formrow">
            <div class="fd-label">Airport image</div>
            <div>
              @if($currentImg)
                <div class="mb-3">
                  <img src="{{ $currentImg }}" alt="Airport image" class="fd-img" onerror="this.style.display='none';">
                  <div class="form-check mt-2">
                    <input class="form-check-input" type="checkbox" id="remove_image" name="remove_image" value="1">
                    <label class="form-check-label" for="remove_image" style="font-size:12px;">Remove image</label>
                  </div>
                </div>
              @endif

              <div class="row g-2">
                <div class="col-12">
                  <label class="form-label mb-1" style="font-size:12px;">Image URL (optional)</label>
                  <input class="form-control" type="url" name="image_url"
                         placeholder="https://example.com/airport.jpg"
                         value="{{ old('image_url', $meta->image_url) }}">
                  <div class="fd-help">Paste a direct image link. If set, URL is used unless you upload a file.</div>
                </div>

                <div class="col-12">
                  <label class="form-label mb-1" style="font-size:12px;">Upload image (optional)</label>
                  <input class="form-control" type="file" name="image" accept="image/*">
                  <div class="fd-help">Max 4MB. Stored on public disk. Upload overrides URL.</div>
                </div>
              </div>
            </div>
          </div>

          <div class="fd-actions">
            <button class="btn btn-primary" type="submit">Save</button>
            <a class="btn btn-outline-secondary" href="{{ route('featureddestination.admin.airports.index') }}">Cancel</a>
            <div class="fd-help mt-2">Tip: Use short descriptions for widgets; long descriptions for airport pages.</div>
          </div>

        </form>
      </div>
      <div style="border-top:3px solid #0b78b6;"></div>
    </div>

    <div class="fd-section">
      <div class="fd-section-title">Airport Info (core)</div>
      <div class="fd-section-body">

        <div class="mb-2"><span class="fd-mini">ID:</span> <strong>{{ $airportId }}</strong></div>
        <div class="mb-2"><span class="fd-mini">Name:</span> <strong>{{ $airportName ?: '—' }}</strong></div>

        <div class="d-flex gap-2 flex-wrap mb-3">
          <span class="fd-pill">IATA: <strong>{{ $iata ?: '—' }}</strong></span>
          <span class="fd-pill">ICAO: <strong>{{ $icao ?: '—' }}</strong></span>
        </div>

        <div class="mb-3">
          <div class="fd-mini">Location</div>
          <div><strong>{{ $locLine }}</strong></div>
        </div>

        @if(property_exists($airport, 'region'))
          <div class="mb-2"><span class="fd-mini">Region:</span> <strong>{{ $region ?: '—' }}</strong></div>
        @endif
        @if(property_exists($airport, 'country'))
          <div class="mb-2"><span class="fd-mini">Country:</span> <strong>{{ $country ?: '—' }}</strong></div>
        @endif
        @if(property_exists($airport, 'location'))
          <div class="mb-2"><span class="fd-mini">Location field:</span> <strong>{{ $location ?: '—' }}</strong></div>
        @endif

        <hr>

        <div class="fd-mini mb-2">Meta status</div>
        <div class="d-flex flex-column gap-1">
          <div>
            Featured:
            @if((int)($meta->is_featured ?? 0) === 1)
              <span class="badge bg-success">Yes</span>
            @else
              <span class="badge bg-secondary">No</span>
            @endif
          </div>
          <div>
            Image:
            @if(!empty($meta->image_url) || !empty($meta->image_path))
              <span class="badge bg-info">Yes</span>
            @else
              <span class="badge bg-light text-muted border">No</span>
            @endif
          </div>
          <div>Priority: <strong>{{ $meta->priority ?? 100 }}</strong></div>
        </div>

      </div>
      <div style="border-top:3px solid #0b78b6;"></div>
    </div>
  </div>
</div>
@endsection
