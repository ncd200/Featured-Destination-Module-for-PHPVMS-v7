@extends('featureddestination::layouts.admin')

@section('title', 'Featured Destinations')

@section('fd_admin_content')

@php
  // simple helpers
  $enabled  = old('fd_enabled', $fd_enabled ?? '1') === '1';
  $showImgs = old('fd_show_images', $fd_show_images ?? '1') === '1';
  $mode     = old('fd_rotation_mode', $fd_rotation_mode ?? 'manual');
@endphp

<style>
  /* Lightweight, module-local styling (matches the screenshot vibe) */
  .fd-wrap { width: 100%; max-width: none; }
  .fd-topline { border-top: 3px solid #0b78b6; }

  .fd-pagehead { padding: 10px 0 0; }
  .fd-muted { color: rgba(0,0,0,.55); }
  .fd-small { font-size: 12px; }

  .fd-grid {
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: 14px;
  }
  @media (max-width: 1200px) {
    .fd-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
  }
  @media (max-width: 600px) {
    .fd-grid { grid-template-columns: 1fr; }
  }

  .fd-feature {
    background: #fff;
    border: 1px solid rgba(0,0,0,.08);
    border-bottom: 3px solid #0b78b6;
    border-radius: 4px;
    padding: 14px 14px 12px;
    min-height: 92px;
  }
  .fd-feature h6 {
    margin: 0 0 6px;
    font-size: 13px;
    font-weight: 700;
    color: #ff5a1f; /* orange like screenshot headings */
    text-align: center;
  }
  .fd-feature p {
    margin: 0;
    font-size: 12px;
    text-align: center;
    color: rgba(0,0,0,.62);
    line-height: 1.35;
  }

  .fd-section {
    background: #fff;
    border: 1px solid rgba(0,0,0,.08);
    border-radius: 4px;
    margin-top: 14px;
  }
  .fd-section .fd-section-title {
    padding: 10px 12px;
    border-bottom: 1px solid rgba(0,0,0,.06);
    font-size: 13px;
    font-weight: 700;
    text-align: center;
  }
  .fd-section .fd-section-body { padding: 14px 14px 4px; }
  .fd-section .fd-section-footline {
    border-top: 3px solid #0b78b6;
    margin-top: 10px;
  }

  .fd-formrow {
    display: grid;
    grid-template-columns: 220px 1fr;
    gap: 12px;
    padding: 10px 0;
    border-bottom: 1px solid rgba(0,0,0,.06);
    align-items: center;
  }
  .fd-formrow:last-child { border-bottom: 0; }
  .fd-label { font-size: 12px; color: rgba(0,0,0,.75); }
  .fd-help { font-size: 11px; color: rgba(0,0,0,.55); margin-top: 4px; }
  .fd-actions { text-align: center; padding: 12px 0 8px; }
  .fd-actions .btn { min-width: 180px; }

  /* toggle alignment */
  .fd-switch { display: flex; align-items: center; gap: 10px; }
</style>

<div class="fd-wrap">

  <div class="fd-pagehead">
    <div class="fd-small fd-muted">
      This module is designed to manage Featured Destinations shown on your site.
      You can configure rotation rules and enrich airport pages with images and descriptions.
    </div>
    <div class="fd-small fd-muted" style="margin-top:6px;">
      Version: <strong>1.0.0</strong> by <a href="https://vadevstudio.com" target="blank">VADevStudio.com</a>
    </div>
  </div>

  <div class="fd-topline mt-2"></div>

  <div class="text-center mt-3 mb-2" style="font-weight:700;">
    Module Features &amp; Settings
  </div>

  {{-- Feature cards row --}}
  <div class="fd-grid mt-3">
    <div class="fd-feature">
      <h6>Manage Featured Destinations</h6>
      <p>Choose how many airports are featured and how they rotate.</p>
    </div>

    <div class="fd-feature">
      <h6>Time Windows</h6>
      <p>Optionally set featured start/end dates per airport.</p>
    </div>

    <div class="fd-feature">
      <h6>Airport Directory</h6>
      <p>Add images, subtitles and descriptions to every airport.</p>
    </div>

    <div class="fd-feature">
      <h6>Database Safe</h6>
      <p>Tables are created and patched automatically (no migrations).</p>
    </div>
  </div>

  {{-- SETTINGS SECTION --}}
  <div class="fd-section">
    <div class="fd-section-title">Featured Destination Settings</div>

    <div class="fd-section-body">
      <form method="post" action="{{ route('featureddestination.admin.settings.save') }}">
        @csrf

        <div class="fd-formrow">
          <div class="fd-label">Enable module</div>
          <div>
            <div class="fd-switch">
              <input class="form-check-input" style="margin-top:0;" type="checkbox" id="fd_enabled" name="fd_enabled" value="1" {{ $enabled ? 'checked' : '' }}>
              <label class="form-check-label" for="fd_enabled" style="font-size:12px;">
                Featured Destinations are active
              </label>
            </div>
            <div class="fd-help">Disable to hide all featured destination widgets/blocks.</div>
          </div>
        </div>

        <div class="fd-formrow">
          <div class="fd-label">Featured count</div>
          <div>
            <input type="number"
                   class="form-control"
                   name="fd_featured_count"
                   min="1"
                   max="4"
                   value="{{ old('fd_featured_count', $fd_featured_count ?? 4) }}">
            <div class="fd-help">How many destinations to show at once (max: 4).</div>
          </div>
        </div>

        <div class="fd-formrow">
          <div class="fd-label">Rotation mode</div>
          <div>
            <select class="form-select" name="fd_rotation_mode">
              <option value="manual" {{ $mode === 'manual' ? 'selected' : '' }}>Manual (priority order)</option>
              <option value="auto_random" {{ $mode === 'auto_random' ? 'selected' : '' }}>Auto Random (shuffle)</option>
            </select>
            <div class="fd-help">Manual uses airport priority; Auto Random shuffles the featured list.</div>
          </div>
        </div>

        <div class="fd-formrow">
          <div class="fd-label">Period (days)</div>
          <div>
            <input type="number" class="form-control" name="fd_period_days" min="1" max="365"
                   value="{{ old('fd_period_days', $fd_period_days ?? 14) }}">
            <div class="fd-help">Reserved for future automation/rotation logic (safe to keep default).</div>
          </div>
        </div>

        <div class="fd-formrow">
          <div class="fd-label">Show images</div>
          <div>
            <div class="fd-switch">
              <input class="form-check-input" style="margin-top:0;" type="checkbox" id="fd_show_images" name="fd_show_images" value="1" {{ $showImgs ? 'checked' : '' }}>
              <label class="form-check-label" for="fd_show_images" style="font-size:12px;">
                Display airport images in widgets
              </label>
            </div>
            <div class="fd-help">If off, cards will show text only (faster / cleaner layout).</div>
          </div>
        </div>

        <div class="fd-actions">
          <button class="btn btn-primary" type="submit">Save Section Settings</button>
          <div class="fd-help" style="margin-top:8px;">
            Tip: upload airport images and descriptions in <strong>Airport Directory</strong>.
          </div>
        </div>

        <div class="fd-section-footline"></div>
      </form>
    </div>
  </div>

</div>
@endsection
