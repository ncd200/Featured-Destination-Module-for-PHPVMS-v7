<?php

use Illuminate\Support\Facades\Route;
use Modules\FeaturedDestination\Http\Controllers\Admin\FeaturedDestinationAdminController;

// Keep middleware conservative so it works on most installs.
// If your admin uses a specific middleware/guard, replace accordingly.
Route::group([
    'prefix' => 'admin/featureddestination',
    'as' => 'featureddestination.admin.',
    'middleware' => ['web', 'auth'],
], function () {
    Route::get('/settings', [FeaturedDestinationAdminController::class, 'settings'])->name('settings');
    Route::post('/settings', [FeaturedDestinationAdminController::class, 'saveSettings'])->name('settings.save');

    Route::get('/airports', [FeaturedDestinationAdminController::class, 'airportsIndex'])->name('airports.index');
    Route::get('/airports/{airport_id}', [FeaturedDestinationAdminController::class, 'airportsEdit'])->name('airports.edit');
    Route::post('/airports/{airport_id}', [FeaturedDestinationAdminController::class, 'airportsUpdate'])->name('airports.update');
});
