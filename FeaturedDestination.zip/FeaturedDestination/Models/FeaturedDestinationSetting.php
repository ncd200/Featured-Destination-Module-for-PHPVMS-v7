<?php

namespace Modules\FeaturedDestination\Models;

use Illuminate\Database\Eloquent\Model;

class FeaturedDestinationSetting extends Model
{
    protected $table = 'fd_settings';

    protected $fillable = [
        'key',
        'value',
    ];

    public static function getValue(string $key, $default = null)
    {
        $row = static::query()->where('key', $key)->first();
        return $row ? $row->value : $default;
    }

    public static function setValue(string $key, $value): void
    {
        static::query()->updateOrCreate(
            ['key' => $key],
            ['value' => (string) $value]
        );
    }
}
