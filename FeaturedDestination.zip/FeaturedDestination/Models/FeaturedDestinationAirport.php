<?php

namespace Modules\FeaturedDestination\Models;

use Illuminate\Database\Eloquent\Model;

class FeaturedDestinationAirport extends Model
{
    protected $table = 'fd_airports';

    protected $fillable = [
        'airport_id',
        'title',
        'subtitle',
        'description',
        'priority',
        'is_featured',
        'featured_from',
        'featured_to',
        'image_path',
        'image_url', // ✅ new
    ];

    protected $casts = [
        'is_featured'   => 'boolean',
        'priority'      => 'integer',
        'featured_from' => 'datetime',
        'featured_to'   => 'datetime',
    ];

    /**
     * Return final image to use: URL has priority, otherwise uploaded file.
     */
    public function resolvedImageUrl(): ?string
    {
        if (!empty($this->image_url)) return $this->image_url;
        if (!empty($this->image_path)) return asset('storage/'.$this->image_path);
        return null;
    }
}
